<div class="container">
  <div class="row">
    <div class="col-md-12 col-lg-12">
			<h1 class="page-header">Updates from DDU</h1>  
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h3>Go Green Go Paperless</h3>
			<img src="images/gogreen.jpg" class="img-responsive" alt="">
			<p class="lead">New Initiative for hasselfree attendance taking. Attendance are made now simpler for Faculty as well as Students.</p>
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h3>mAttendace is Device independant?</h3>
			<p>mAtttendace is Dynamic and Robust. It wokrs on across the devices covering Andoid, iOS, Windows, Blackberry. I works very fine your Tables/Phables as well.</p>
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h3>From where I could get login details for attendance taking?</h3>
			<p>mAtttendace is Dynamic and Robust. Your HOD have access to create your account for attendance taking</p>
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h3>How Students and Subjects are assigned to me?</h3>
			<p>mAtttendace is Dynamic and Robust. Your HOD will do the needful for you from his admin access.</p>
		</div>
	</div>
		
</div>