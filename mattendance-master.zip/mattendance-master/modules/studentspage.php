<div class="container">
  <div class="row">
    <div class="col-md-12 col-lg-12">
			<h1 class="page-header">Updates from DDU</h1>  
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h3>Go Green Go Paperless</h3>
			<img src="images/gogreen.jpg" class="img-responsive" alt="">
			<p class="lead">New Initiative for hasselfree attendance taking. Attendance are made now simpler for Faculty as well as Students.</p>
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h3>Friends attendace are important!</h3>
			<p>As our policy 75% attendace is compulsary. Please check your latest attendace records from "Student Section".</p>
		</div>
	</div>
	
</div>